package com.jt.common.aspect;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;
@Order(2)
@Aspect
@Service
public class SysCacheAspect {
	
	
	
}
